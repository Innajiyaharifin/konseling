<?php 
include "koneksi.php";

$id_konseling=$_POST['id_konseling'];
$id_siswa=$_POST['id_siswa'];
$isi_konseling=$_POST['isi_konseling'];
//$nama_konseling=$_POST['nama_konseling'];
//$status=$_POST['status'];


$sql = "INSERT into tb_konseling (isi_konseling, id_konseling, id_siswa) values ('$isi_konseling', '$id_konseling', '$id_siswa')";
$proses = mysqli_query($db, $sql);
var_dump($sql);
var_dump($proses);
if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="datakonselingall.php";
	</script>
<?php 
}
 ?>