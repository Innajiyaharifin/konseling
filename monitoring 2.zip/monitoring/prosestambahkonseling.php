<?php 
include "koneksi.php";

$id_guru=$_POST['id_guru'];
$tanggalmulai=$_POST['tanggalmulai'];
$jenis_konseling=$_POST['jenis_konseling'];
$nama_konseling=$_POST['nama_konseling'];
$status=$_POST['status'];


$sql = "INSERT into tb_jadwal_konseling (tanggal, nama_konseling, jenis_konseling, status, id_guru) values ('$tanggalmulai', '$jenis_konseling', '$nama_konseling', '$status', '$id_guru')";
$proses = mysqli_query($db, $sql);
var_dump($sql);
var_dump($proses);
if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="datakonseling.php";
	</script>
<?php 
}
 ?>