

 <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a class="has-arrow" href="datasiswapribadi.php">
                                   <i class="icon nalika-home icon-wrap"></i>
                                   <span class="mini-click-non">Data Siswa</span>
                                </a>
                           </li>
                        
                        </li>
                        <li>
                            <a class="has-arrow" href="datakonselingall.php" aria-expanded="false"><i class="icon nalika-mail icon-wrap"></i> <span class="mini-click-non">Data Konseling</span></a>
                           
                        </li>
                         <li>
                            <a class="has-arrow" href="datanilaipribadisiswa.php" aria-expanded="false"><i class="icon nalika-mail icon-wrap"></i> <span class="mini-click-non">Data Nilai</span></a>
                           
                        </li>
                        <li>
                            <a class="has-arrow" href="grafiksiswa.php" aria-expanded="false"><i class="icon nalika-pie-chart icon-wrap"></i> <span class="mini-click-non">Perkembangan</span></a>
                         
                        </li>
                         <li>
                            <a class="has-arrow" href="perkembangan.php" aria-expanded="false"><i class="icon nalika-pie-chart icon-wrap"></i> <span class="mini-click-non">Pilih Jurusan</span></a>
                         
                        </li>
                        <li>
                            <a class="has-arrow" href="logout.php" aria-expanded="false"><i class="icon nalika-bar-chart icon-wrap"></i> <span class="mini-click-non">Logout</span></a>
                            
                        </li>
                        
                    </ul>
                </nav>