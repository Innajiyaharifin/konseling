<?php 
session_start();
session_destroy();
include "login.php";


 ?>