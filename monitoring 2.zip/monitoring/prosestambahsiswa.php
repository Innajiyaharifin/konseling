<?php 
include "koneksi.php";

$nama=$_POST['nama'];
$nis=$_POST['alamat'];
$tempatlahir=$_POST['tempatlahir'];
$tanggallahir=$_POST['tanggallahir'];
$email=$_POST['email'];
$hp=$_POST['hp'];
$kelas=$_POST['kelas'];
$jurusan=$_POST['jurusan'];
$alamat=$_POST['alamat'];
$foto=$_FILES['foto']['name'];
$lokasifoto=$_FILES['foto']['tmp_name'];


move_uploaded_file($lokasifoto, 'img/$foto');


$sql = "INSERT into tb_siswa (NIS, nama_lengkap, tempat_lahir, tanggal_lahir, email, no_hp, kelas,jurusan,alamat,foto,id_user) values ('$nama', '$nis', '$tempatlahir', '$tanggallahir', '$email','$hp','$kelas','$jurusan','$alamat','$foto','0')";
$proses = mysqli_query($db, $sql);
if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="datasiswa.php";
	</script>
<?php 
}
 ?>