<?php 
include "koneksi.php";

$id=$_POST['id'];
$nama=$_POST['nama'];
$nis=$_POST['nis'];
$tempatlahir=$_POST['tempatlahir'];
$tanggallahir=$_POST['tanggallahir'];
$email=$_POST['email'];
$hp=$_POST['hp'];
$kelas=$_POST['kelas'];
$jurusan=$_POST['jurusan'];
$alamat=$_POST['alamat'];
$foto=$_FILES['foto']['name'];
$lokasifoto=$_FILES['foto']['tmp_name'];


move_uploaded_file($lokasifoto, 'img/$foto');


$sql = "UPDATE  tb_siswa set NIS = '$nis', 
							nama_lengkap= '$nama', 
							tempat_lahir= '$tempatlahir', 
							tanggal_lahir= '$tanggallahir', 
							email = '$email', 
							no_hp = '$hp', 
							kelas = '$kelas',
							jurusan = '$jurusan',
							alamat = '$alamat',
							foto = '$foto' 
							WHERE id = '$id'";
$proses = mysqli_query($db, $sql);
if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil diubah');
		window.location="datasiswa.php";
	</script>
<?php 
}
 ?>