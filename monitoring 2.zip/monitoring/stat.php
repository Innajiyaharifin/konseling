<?php
 
include "koneksi.php";
// membaca nim dari parameter 
$id = $_GET['id'];
 

 
// menyiapkan array untuk menyimpan smt dan tahun
$smtThn = array();
 
// menyiapkan array untuk menyimpan ip
$nilai = array();
 
// memanggil modul JpGraph untuk membuat grafik batang dan garis
// modul ini terletak dalam folder bernama 'modul'
include ("jpgraph-4.3.1/src/jpgraph.php");
include ("jpgraph-4.3.1/src/jpgraph_bar.php");
include ("jpgraph-4.3.1/src/jpgraph_line.php");
 
// query sql untuk mendapatkan IP setiap semester dari mahasiswa
$query = "SELECT semester, nilai_akhir as nilai
          FROM tb_nilai
          WHERE id_siswa = '$id'
          GROUP BY semester";
           
$hasil = mysqli_query($db,$query);
while ($data = mysqli_fetch_array($hasil))
{
  // menyimpan data semester dan tahun hasil query ke dalam array $smtThn
  // smt dan tahun digabung dalam satu string untuk ditampilkan dalam sumbu-y grafik
  array_unshift($smtThn, $data['semester']);
   
  // menyimpan data IP hasil query ke dalam array $ip
  array_unshift($nilai, $data['nilai']);
}
 
// membuat image ukuran 500 x 300 pixel 
$graph = new Graph(500,300,"auto");
 
// membuat skala grafik. Nilai 4 di sini adalah nilai maksimum sumbu Y nya, mengingat IP maks adalah 4    
$graph->SetScale("textlin", 10, 100);
 
// membuat bayangan dari image
$graph->SetShadow();
 
// mengatur batas margin grafik
$graph->SetMargin(50,50,40,40);
 
// membuat bar plot dari data IP
$barplot = new BarPlot($nilai);
 
// membuat line plot dari data IP
$lineplot=new LinePlot($nilai);
 
// memberi warna merah pada bar plot
$barplot->SetFillColor("red");
 
// menampilkan value IP pada setiap bar
$barplot->value->show();
 
// mengatur tampilan value IP dengan format 1 digit desimal di belakang koma
$barplot ->value->SetFormat("%3.1f");
 
// mengatur ketebalan garis pada lineplot
$lineplot->SetWeight(3);
 
// mengatur posisi ujung line plot supaya terletak di tengah-tengah bar  
$lineplot->SetBarCenter();
 
// menampilkan barplot ke dalam image
$graph->Add($barplot);
 
// menampilkan lineplot ke dalam image
$graph->Add($lineplot);
 
// menampilkan smt dan tahun pada sumbu X
$graph->xaxis-> SetTickLabels($smtThn);
 
// menampilkan title grafik
$graph->title->Set("Grafik Indeks Prestasi Mahasiswa");
 
// memberi label pada sumbu X
$graph->xaxis->title->Set("Semester");
 
// memberi label pada sumbu Y
$graph->yaxis->title->Set("Indeks Prestasi (IP)");
 
// mengatur jenis font pada title, label sumbu X dan label sumbu Y
$graph->title->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
 
// menampilkan output grafik 
$graph->Stroke();
?>