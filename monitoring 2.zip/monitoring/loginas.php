<?php 

include "koneksi.php";
$id = $_GET['id'];


$sql = "SELECT * FROM user where id = '$id'";
$baca = mysqli_query($db, $sql);
//$itung = mysqli_num_rows($baca);
$data = mysqli_fetch_array($baca);

	if ($baca) {
	session_start();
	$_SESSION['pengguna']=$data['username'];	

	?>
		<script type="text/javascript">
					alert("Berhasil Masuk Ke Sistem");
					window.location="index.php";
		</script>
<?php 
}


 ?>