<?php 
include "koneksi.php";

$id=$_POST['id'];
$Qurdis=$_POST['Qurdis'];
$aqidah_akhlak=$_POST['aqidah_akhlak'];
$FIKIH=$_POST['FIKIH'];
$ski=$_POST['ski'];
$bahasa_arab=$_POST['bahasa_arab'];
$pkn=$_POST['pkn'];
$bahasa_indonesia=$_POST['bahasa_indonesia'];
$bahasa_inggris=$_POST['bahasa_inggris'];
$matematika=$_POST['matematika'];
$sejarah_indonesia=$_POST['sejarah_indonesia'];
$fisika_geografi=$_POST['fisika_geografi'];
$kimia_ekonomi=$_POST['kimia_ekonomi'];
$biologi_sosiologi=$_POST['biologi_sosiologi'];
$geografi_kimia=$_POST['geografi_kimia'];
$seni_budaya=$_POST['seni_budaya'];
$penjaskes=$_POST['penjaskes'];
$prakarya=$_POST['prakarya'];
$bahasa_sunda=$_POST['bahasa_sunda'];
$mulok_komputer=$_POST['mulok_komputer'];
$mulok_plh=$_POST['mulok_plh'];
$mulok_nahwu=$_POST['mulok_nahwu'];

$nilai_akhir = ($Qurdis+$aqidah_akhlak+$FIKIH+$ski+$bahasa_arab+$pkn+$bahasa_indonesia+$bahasa_inggris+$matematika+$sejarah_indonesia+$fisika_geografi+$kimia_ekonomi+$biologi_sosiologi+$geografi_kimia+$seni_budaya+$penjaskes+$prakarya+$bahasa_sunda+$mulok_komputer+$mulok_plh+$mulok_nahwu)/21;



$sql = "INSERT into tb_nilai (Qurdis, aqidah_akhlak, FIKIH, ski, bahasa_arab, pkn, bahasa_indonesia, bahasa_inggris, matematika,  sejarah_indonesia, fisika_geografi, kimia_ekonomi, biologi_sosiologi,  geografi_kimia, seni_budaya,penjaskes, prakarya, bahasa_sunda, mulok_komputer, mulok_plh, mulok_nahwu, id_siswa,nilai_akhir) values ('$Qurdis', '$aqidah_akhlak', '$FIKIH', '$ski', '$bahasa_arab','$pkn','$bahasa_indonesia','$bahasa_inggris','$matematika','$sejarah_indonesia','$fisika_geografi','$kimia_ekonomi','$biologi_sosiologi','$geografi_kimia','$seni_budaya', '$penjaskes','$prakarya', '$bahasa_sunda', '$mulok_komputer', '$mulok_plh', '$mulok_nahwu', '$id','$nilai_akhir')";
$proses = mysqli_query($db, $sql);
var_dump($sql);
var_dump($proses);
if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="datanilai.php";
	</script>
<?php 
}
 ?>