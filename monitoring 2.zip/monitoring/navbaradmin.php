
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a class="has-arrow" href="datapengguna.php">
								   <i class="icon nalika-home icon-wrap"></i>
								   <span class="mini-click-non">Data Pengguna</span>
								</a>
                           
                        </li> <li>
                            <a class="has-arrow" href="logout.php" aria-expanded="false"><i class="icon nalika-pie-chart icon-wrap"></i> <span class="mini-click-non">Logout</span></a>
                           
                        </li>
                       
                </nav>
   