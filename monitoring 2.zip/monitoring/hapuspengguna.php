<?php 
include "koneksi.php";


$id = $_GET['id'];
$sql = "DELETE FROM user where id='$id'";
$baca = mysqli_query ($db, $sql);

if ($baca) {
	?>
	<script type="text/javascript">
		alert("data berhasil dihapus")
		window.location="datapengguna.php";
	</script>
<?php 
}



 ?>