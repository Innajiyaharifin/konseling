<?php 
include "koneksi.php";

$id=$_POST['id'];
//$id_soal = $_POST['id_soal'];
$Qurdis=$_POST['Qurdis'];
$aqidah_akhlak=$_POST['aqidah_akhlak'];
$FIKIH=$_POST['FIKIH'];
$ski=$_POST['ski'];
$bahasa_arab=$_POST['bahasa_arab'];
$pkn=$_POST['pkn'];
$bahasa_indonesia=$_POST['bahasa_indonesia'];
$bahasa_inggris=$_POST['bahasa_inggris'];
$matematika=$_POST['matematika'];
$sejarah_indonesia=$_POST['sejarah_indonesia'];
$fisika_geografi=$_POST['fisika_geografi'];
$kimia_ekonomi=$_POST['kimia_ekonomi'];
$biologi_sosiologi=$_POST['biologi_sosiologi'];
$geografi_kimia=$_POST['geografi_kimia'];
$seni_budaya=$_POST['seni_budaya'];
$penjaskes=$_POST['penjaskes'];
$prakarya=$_POST['prakarya'];
$bahasa_sunda=$_POST['bahasa_sunda'];
$mulok_komputer=$_POST['mulok_komputer'];
$mulok_plh=$_POST['mulok_plh'];
$mulok_nahwu=$_POST['mulok_nahwu'];

$nilai_akhir = ($Qurdis+$aqidah_akhlak+$FIKIH+$ski+$bahasa_arab+$pkn+$bahasa_indonesia+$bahasa_inggris+$matematika+$sejarah_indonesia+$fisika_geografi+$kimia_ekonomi+$biologi_sosiologi+$geografi_kimia+$seni_budaya+$penjaskes+$prakarya+$bahasa_sunda+$mulok_komputer+$mulok_plh+$mulok_nahwu)/21;



$sql = "UPDATE tb_nilai set Qurdis='$Qurdis', 
							aqidah_akhlak='$aqidah_akhlak', 
							FIKIH='$FIKIH', 
							ski='$ski', 
							bahasa_arab='$bahasa_arab', 
							pkn='$pkn', 
							bahasa_indonesia='$bahasa_indonesia', 
							bahasa_inggris='$bahasa_inggris', 
							matematika='$matematika',  
							sejarah_indonesia='$sejarah_indonesia',
							 fisika_geografi='$fisika_geografi', 
							 kimia_ekonomi='$kimia_ekonomi', 
							 biologi_sosiologi='$biologi_sosiologi',  
							 geografi_kimia='$geografi_kimia', 
							 seni_budaya='$seni_budaya',
							 penjaskes='$penjaskes', 
							 prakarya='$prakarya', 
							 bahasa_sunda='$bahasa_sunda', 
							 mulok_komputer='$mulok_komputer', 
							 mulok_plh='$mulok_plh', 
							 mulok_nahwu='$mulok_nahwu', 
						
							 nilai_akhir ='$nilai_akhir' WHERE id = '$id'";


$proses = mysqli_query($db, $sql);

if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil diubah');
		window.location="datanilai.php";
	</script>
<?php 
}
 ?>