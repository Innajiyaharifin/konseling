<?php 


$db=mysqli_connect("localhost","root","","monitoring_konseling");
if (!$db) {
	echo "Gagal";
}



 ?>