<?php 
include "koneksi.php";


$id = $_GET['id'];
$sql = "DELETE FROM tb_siswa where id='$id'";
$baca = mysqli_query ($db, $sql);

if ($baca) {
	?>
	<script type="text/javascript">
		alert("data berhasil dihapus")
		window.location="datasiswa.php";
	</script>
<?php 
}



 ?>