<?php 
include "koneksi.php";

$id=$_POST['id'];
$hobi=$_POST['hobi'];


move_uploaded_file($lokasifoto, 'img/$foto');


$sql = "UPDATE  tb_siswa set hobi_bakat = '$hobi'
							WHERE id = '$id'";
$proses = mysqli_query($db, $sql);
if ($proses) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil diubah');
		window.location="datanonakademik.php";
	</script>
<?php 
}
 ?>